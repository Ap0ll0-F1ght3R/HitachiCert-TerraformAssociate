## Requirements

| Name | Version |
|------|---------|
| aws | ~> 2.0 |

## Providers

| Name | Version |
|------|---------|
| aws | ~> 2.0 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| bucket | Name of the s3 bucket to be created. | `string` | n/a | yes |
| region | Name of the s3 bucket to be created. | `string` | `"us-east-1"` | no |

## Outputs

No output.
